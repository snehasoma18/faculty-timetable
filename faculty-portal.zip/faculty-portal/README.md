# 🎓 Faculty Timetable Portal

A student-facing web portal to easily find faculty schedules, free slots, and contact information — all in one place.

## ✨ Features

- 📅 Full weekly timetable for each faculty member
- 🟢 Real-time **"Free Now"** / **"In Class"** status based on current time
- 🔍 Search faculty by name, department, or cabin number
- 🏢 Filter by department
- 📞 Contact modal with email, phone, and cabin info
- 🖨️ Print-friendly timetable view
- ⭐ Today's column highlighted
- ⏰ Current period highlighted with "NOW" indicator
- 📱 Fully mobile responsive

## 🚀 Deployed at

> **GitHub Pages URL:** `https://<your-username>.github.io/<repo-name>/`

## 🛠 How to Customize

Open `index.html` and edit the `FACULTY` array near line 200. Each faculty entry looks like:

```js
{
  id: 1,
  name: 'Dr. Sunita Rao',
  short: 'Sunita Rao',       // shown in quick picks
  dept: 'CSE',               // must match a key in DEPT_COLORS
  cabin: 'CS-104',
  email: 'sunita@college.edu',
  phone: '+91 98765 43210',
  qual: 'Ph.D. (IIT Delhi)', // qualification
  timetable: {
    Monday:    [slot0, slot1, null, slot3, slot4, null, slot6, slot7, slot8],
    Tuesday:   [...],
    Wednesday: [...],
    Thursday:  [...],
    Friday:    [...],
    Saturday:  [...],
  }
}
```

### Timetable Slot Format

Each slot is either `null` (free) or an object:

```js
{ sub: 'Data Structures', room: 'CS-201', batch: 'CSE-A', lab: false }
// lab: true adds a "LAB" badge to the cell
```

### Slot Index Mapping

The array has **9 elements** per day (matching the 9 TIME_SLOTS):

| Index | Period      | Time           |
|-------|-------------|----------------|
| 0     | Period 1    | 9:00 – 9:50    |
| 1     | Period 2    | 9:50 – 10:40   |
| 2     | Period 3    | 10:55 – 11:45  |
| 3     | Period 4    | 11:45 – 12:35  |
| 4     | Period 5    | 1:30 – 2:20    |
| 5     | Period 6    | 2:20 – 3:10    |
| 6     | Period 7    | 3:10 – 4:00    |

> Note: The array has 9 positions (0–8) but indices 2 and 5 in `TIME_SLOTS` are BREAK rows. The actual data array skips those — use 7 slots per day in the data.
> 
> Actually looking at the data, the timetable uses **9-element arrays** where the app maps them directly to the 9 TIME_SLOT entries (including break positions). Breaks are rendered as rows but the data values at break-index positions are ignored.

### Adding New Departments

Add a color to `DEPT_COLORS`:

```js
const DEPT_COLORS = {
  CSE:   '#3B82F6',
  MATH:  '#10B981',
  // add yours:
  BIO:   '#22D3EE',
};
```

## 📁 File Structure

```
faculty-portal/
└── index.html    ← The entire app (single file, no dependencies)
└── README.md
```

## 📄 License

Free to use and modify for educational purposes.
